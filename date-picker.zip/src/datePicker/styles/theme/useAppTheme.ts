import { useTheme } from "react-jss";

export const useAppTheme =  useTheme<Theme>